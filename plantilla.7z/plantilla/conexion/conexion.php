<?php
    $host = "localhost";
    $user = "root";
    $pass = "";
    $bd = "clase_php";
    //enviar los parametros para abrir la conexion
    $conn = mysqli_connect(hostname: $host, username:$user, password:$pass, database:$bd);

    if(!$conn){
        die("Error de conexion". mysqli_connect_error());
    }