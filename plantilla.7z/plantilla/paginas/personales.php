<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <link rel="stylesheet" href="../css/style.css">
    <title>Document</title>
</head>
<body>
    <header>

    </header>
    <main>
        <button onclick="abrir()">NUEVO PERSONAL</button>
        <h1 id="resultado"></h1>
        <table id="tablepersonales " border="1">
            <thead>
                <th>NOMBRE</th>
                <th>APELLIDO</th>
                <th>CI</th>
                <th>TELEFONO</th>
                <tbody>

                </tbody>
            </thead>
            </table>
    </main>
    <footer>
            <div id="modal" class="modal">
            <div class="modal-content">
                <span class="close" onclick="cerrar()">&times;</span>
                <h1>NUEVO CLIENTE</h1>
                <form id="cliente">
                    <label>NOMBRE</label>
                    <input type="text" id="txtnombre"><br>
                    <label>APELLIDO</label>
                    <input type="text" id="txtapellido"><br>
                    <label>CI</label>
                    <input type="text" id="txtci"><br>
                    <label>TELEFONO</label>
                    <input type="tetx" id="txttelefono"><br>
                    <button type="submit">GUARDAR</button>
                </form>
            </div> 

        </div>
        <script src="../js/script.js"></script>
        <script src="../js/personales.js"></script>
    </footer>

</body>
</html>