<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <title>PRODUCTOS</title>
</head>
<body>
    <header>
       
    </header>
     <main>
        <button onclick="abrir()">NUEVO PRODUCTO</button>
        <h1 id="resultado"></h1>
    </main>

        <footer>
            <div id="modal" class="modal">
            <div class="modal-content">
                <span class="close" onclick="cerrar()">&times;</span>
                <h1>NUEVO PRODUCTO</h1>
                <form id="productos">
                    <label>NOMBRE</label>
                    <input type="text" id="txtnombre"><br>
                    <label>COSTO</label>
                    <input type="number" id="txtcosto"><br>
                    <label>PRECIO</label>
                    <input type="number" id="txtprecio"><br>
                    <label>STOCK</label>
                    <input type="number" id="txtstock"><br>

                    <button type="submit">GUARDAR</button>
                    <select id="cmbiva">
                        <option value="0">EXENTA</option>
                        <option value="5">5 %</option>
                        <option value="10">10 %</option>
                    </select>
                </form>
            </div>   
            
        </footer> 

         </div>
         <script src="../js/script.js"></script>
         <script src="../js/productos.js"></script>
</body>
</html>