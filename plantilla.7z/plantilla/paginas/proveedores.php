<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <title>Document</title>
</head>
<body>
    <header>   

   </header>
   <main>
    <button onclick="abrir()">NUEVO PROVEEDOR</button>
    <h1 id="resultado"></h1>

   </main>
   <footer>

   </footer>
   <div id="modal-content">
    <div class="modal-content">
     <span class="close" onclick="cerrar()">&times;</span>
        <h1>PROVEEDORES</h1>
        <form id="usuarios">
            <labe>NOMBRE</label>
            <input type="text" id="txtnombre"><br>
            <label>RUC</label>
            <input type="text" id="txtruc"><br>
            <label>TELEFONO</label>
            <input type="text" id="txttelefono"><br>
            <label>CORREO</label>
            <input type="text" id="txtcorreo"><br>

            <button type="submit">GUARDAR</button>
         </form>
   </div>

   </div>
   <script src="../js/script.js"></script>
    <script src="../js/proveedores.js"></script>

</body>
</html>