<?php
    session_start();
    if(isset($_SESSION['idusuarios'])){
        header("Location:../login.php");
        exit();
    }
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <title>CLIENTES</title>
</head>
<body>
    <header>
       
    </header>
     <main>
        <div>
        <button onclick="abrir()">NUEVO CLIENTE</button>
        <h1 id="resultado"></h1>
        <table id="tablaclientes" border="1">
            <thead>
                <th>CODIGO</th>
                <th>NOMBRE</th>
                <th>APELLIDO</th>
                <th>CI Nº</th>
                <th>ACCIONES</th>
            </thead>
            <tbody>

            </tbody>
        </table>
        </div>
    </main>
    <footer>
    </footer> 
        <div id="modal" class="modal">
            <div class="modal-content">
                <span class="close" onclick="cerrar()">&times;</span>
                <h1>NUEVO CLIENTE</h1>
                <form id="cliente">
                    <label>NOMBRE</label>
                    <input type="text" id="txtnombre"><br>
                    <label>APELLIDO</label>
                    <input type="text" id="txtapellido"><br>
                    <label>RUC</label>
                    <input type="text" id="txtruc"><br>
                    <button type="submit">GUARDAR</button>
                </form>
            </div>   
         </div>
         <!--modal para modificar-->
         <div id="modalEditar" class="modal">
            <div class="modal-content">
                <span class="close" onclick="cerrarEditar()">&times;</span>
                <form id="formEditar">
                    <input type="hidden" id="txtcodigoM">
                    <label>NOMBRE</label>
                    <input type="text" id="txtnombreM"><br>
                    <label>APELLIDO</label>
                    <input type="text" id="txtapellidoM"><br>
                    <label>RUC</label>
                    <input type="text" id="txtrucM">
                    <button type="submit">MODIFICAR</button>
                </form>
            </div>
         </div>
         <script src="../js/script.js"></script>
         <script src="../js/cliente.js"></script>
</body>
</html>