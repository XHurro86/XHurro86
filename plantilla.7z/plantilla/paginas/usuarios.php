<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <link rel="stylesheet" href="../css/style.css">
    <title>Document</title>
</head>
<body>
   <header>

   </header>
   <main>
    <button onclick="abrir()">NUEVO USUARIO</button>
    <h1 id="resulado"></h1>
   </main>

   <footer>

   </footer>
   <div id="modal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="cerrar()">&times;</span>
        <h1>NUEVO USUARIO</h1>
        <form id="usuarios">
            <labe>NOMBRE</label>
            <input type="text" id="txtnombre"><br>
            <label>CLAVE</label>
            <input type="text" id="txtclave"><br>
            <label>TIPO</label>
            <input type="text" id="txttipo"><br>
            <label>ESTADO</label>
            <input type="text" id="txtestado"><br>

            <button type="submit">GUARDAR</button>

        </form>
    </div>
    <script src="../js/script.js"></script>
    <script src="../js/usuarios.js"></script>

   </div>
</body>
</html>