<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form id="login">
        <label>USER</label><br>
        <input type="text" id="txtusuario"><br>
        <label>CLAVE</label><br>
        <input type="password" id="txtclave"><br>
        <button type="submit">INGRESAR</button>
        <h2 id="resultado"></h2>
    </form>
    <script src="js/login.js"></script>
</body>
</html>