function abrir() {
    const modal = document.getElementById('modal');
    modal.style.display = "flex"; // flex para centrar con align/justify
}

function cerrar() {
    const modal = document.getElementById('modal');
    modal.style.display = "none";
}

// Extra: cerrar al hacer click fuera del contenido
window.onclick = function(event) {
    const modal = document.getElementById('modal');
    if (event.target === modal) {
        cerrar();
    }
}

// Extra: cerrar con la tecla Escape
document.addEventListener('keydown', function(event) {
    if (event.key === "Escape") {
        cerrar();
    }
});
