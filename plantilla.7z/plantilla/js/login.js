document.getElementById('login').addEventListener("submit", function(e){
    e.preventDefault();
    //entrada de datos
        let user = document.getElementById('txtusuario').value;
        let clave = document.getElementById('txtclave').value;

        //envio al back
        let xhr = new XMLHttpRequest();
        xhr.open("POST", "php/login.php", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xhr.send("usuario="+user+"&clave="+clave+"&action=login");

    //salida
        xhr.onload = function(){
            if(xhr.status === 200){
                document.getElementById('resultado').innerText = xhr.responseText;
                //si es correcto debe redireccionar del login.php al menu (index.php)
                if(xhr.responseText.includes("OK")){
                    window.location.href = "index.php"
                };
            }
        }
});