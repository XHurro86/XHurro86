document.getElementById('usuarios').addEventListener('submit', function(e){
    e.preventDefault();

    let nombre=document.getElementById('txtnombre').value;
    let clave=document.getElementById('txtclave').value;
    let tipo=document.getElementById('txttipo').value;
    let estado=document.getElementById('txtestado').value;

    let xhr = new XMLHttpRequest();
    xhr.open("POST","../php/usuariosbach.php",true);
     xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
     
     xhr.send("nombrephp="+nombre+"&clavephp="+clave+"&tipophp="+tipo+"&estadophp="+estado);
     xhr.onload = function(){
        if (xhr.status ==200){
            document.getElementById('resultado').innerText=xhr.responseText;
            document.getElementById('modal').style.display="none";

        }
     }
});