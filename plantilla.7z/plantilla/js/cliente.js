//la funcion es solo para insertar
document.getElementById('cliente').addEventListener("submit", function(e){
    e.preventDefault();

    let nombre = document.getElementById('txtnombre').value;
    let apellido = document.getElementById('txtapellido').value;
    let ruc = document.getElementById('txtruc').value;

    let xhr = new XMLHttpRequest();
    xhr.open("POST", "../php/clienteback.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

    xhr.send("nombrephp="+nombre+"&apellidophp="+apellido+"&rucphp="+ruc+"&accion=insertar");

    xhr.onload = function(){
        if(xhr.status == 200){
            document.getElementById('resultado').innerText= xhr.responseText;
            document.getElementById('modal').style.display = "none";
        }

    }

});
//metodo para listar
function listar(){
    //hacemos una peticion ajax
    let xhr = new XMLHttpRequest();
    xhr.open("GET", "../php/clienteback.php?accion=listar", true);
    //se coloca send porque debe existir la peticion al back
    xhr.send();
    //recibira el resultado del back para mostrar en el front
    xhr.onload = function(){
        if(xhr.status === 200){
            //recibimos del back el dato y enviamos a la tabla
            let data = JSON.parse(xhr.responseText);
            //el dato recibido se enviara al front (tabla)
            let tbody = document.querySelector("#tablaclientes tbody");
            //limpiar la tabla
            tbody.innerHTML = "";
            //cargar la tabla con los valores de data
            data.forEach(item =>{
                //crear la primera fila en tbody
                //alt + 96 = 
                let fila = `
                    <tr>
                        <td>${item.idclientes}</td>
                        <td>${item.cli_nombre}</td>
                        <td>${item.cli_apellido}</td>
                        <td>${item.cli_ruc}</td>
                        <td>
                        <button onclick= "editar(${item.idclientes}, '${item.cli_nombre}','${item.cli_apellido}','${item.cli_ruc}')">EDITAR</button>
                        <button onclick= "eliminar(${item.idclientes})">Eliminar</button></td>
                    </tr>
                `;
                //la variable fila se agregara al tbody del front
                tbody.innerHTML  += fila;

            });
        }
    }


}







//metodo para modificar
//primero se debe rellenar la ventana modal
function editar(id, nombre, apellido, ruc){
    document.getElementById('txtcodigoM').value= id;
    document.getElementById('txtnombreM').value= nombre;
    document.getElementById('txtapellidoM').value = apellido;
    document.getElementById('txtrucM').value= ruc;
    document.getElementById('modalEditar').style.display = "flex";
}

function cerrarEditar(){
    document.getElementById('modalEditar').style.display = "none";
}

document.getElementById('formEditar').addEventListener("submit", function(e){
    e.preventDefault();

    //primer bloque entrada
    let codigo = document.getElementById('txtcodigoM').value;
    let nombre = document.getElementById('txtnombreM').value;
    let apellido = document.getElementById('txtapellidoM').value;
    let ruc = document.getElementById('txtrucM').value;

    //segundo bloque hacer la  peticion
    let xhr = new XMLHttpRequest();
    xhr.open("POST", "../php/clienteback.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

    //tercer bloque envio de peticion
    xhr.send("codigo="+codigo+"&nombre="+nombre+"&apellido="+apellido+"&ruc="+ruc+"&accion=editar");

    //cuarto bloque resultados
    xhr.onload = function(){
        if(xhr.status === 200){
            document.getElementById('resultado').innerText = xhr.responseText;
            listar();
            cerrarEditar();
        }else{
            document.getElementById('resultado').innerText = "ERROR DE SERVIDOR";
        }
    }
});
//metodo eliminar
    function eliminar(id){
        if(confirm("Desea eliminar al cliente?")){
            //que lo elimine
            let xhr = new XMLHttpRequest();
            xhr.open("POST", "../php/clienteback.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

            xhr.send("codigo="+id+"&accion=eliminar");

            xhr.onload = function(){
                if (xhr.status === 200){
                    document.getElementById('resultado').innerText = xhr.responseText;
                    listar();
                }else{
                    document.getElementById('resultado').innerText = "Error de servidor";
                }
            }
        }

    }



//metodo que se ejecuta antes que se cargue la pagina
window.onload = listar;