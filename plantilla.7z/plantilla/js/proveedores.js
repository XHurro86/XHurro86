document.getElementById('proveedores').addEventListener("submit", function(e){
    e.preventDefault();
     
    let nombre = document.getElementById('txtnombre').value;
    let costo = document.getElementById('txtruc').value;
    let precio = document.getElementById('txttelefono').value;
    let stock = document.getElementById('txtcorreo').value;

    let xhr = new XMLHttpRequest();
    xhr.open("POST", "../php/productosback.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

    xhr.send("nombrephp="+nombre+"&rucphp="+ruc+"&telefonophp="+telefono+"&correophp="+correo);
    
    xhr.onload = function(){
        if(xhr.status == 200){
            document.getElementById('resultado').innerText= xhr.responseText;
            document.getElementById('modal').style.display = "none";
        }
    }

});