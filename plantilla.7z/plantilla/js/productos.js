document.getElementById('productos').addEventListener("submit", function(e){
    e.preventDefault();

    let nombre = document.getElementById('txtnombre').value;
    let costo = document.getElementById('txtcosto').value;
    let precio = document.getElementById('txtprecio').value;
    let stock = document.getElementById('txtstock').value;
    let iva = document.getElementById('cmbiva').value;
    
    let xhr = new XMLHttpRequest();
    xhr.open("POST", "../php/productosback.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

    xhr.send("nombrephp="+nombre+"&costophp="+costo+"&preciophp="+precio+"&stockphp="+stock+"&ivaphp="+iva);

    xhr.onload = function(){
        if(xhr.status == 200){
            document.getElementById('resultado').innerText= xhr.responseText;
            document.getElementById('modal').style.display = "none";
        }

    }

});