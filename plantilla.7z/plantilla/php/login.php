<?php
session_start();//libreria para manipular variables de sesion

require_once("../conexion/conexion.php");
    $user = $_POST['usuario'];
    $pass = $_POST['clave'];
    $action = $_POST['action'];

    if ($action == "login"){
        $sql = "select * from usuarios where usu_nombre='$user' and usu_clave='$pass' and usu_estado = 'ACTIVO'";

        $resultado = mysqli_query($conn, $sql);
        if($resultado && mysqli_num_rows($resultado)>0){
            $row = mysqli_fetch_assoc($resultado);
            echo "OK - Bienvenido ". $row['usu_nombre'];
            //crear la variable de session
            $_SESSION['idusuarios']= $row['idusuarios'];
            $_SESSION['usu_nombre']= $row['usu_nombre'];
            $_SESSION['usu_tipo']= $row['usu_tipo'];
            
        }else{
            echo "NO EXISTEN SUS DATOS O USUARIO INACTIVO";
        }
    }
?>