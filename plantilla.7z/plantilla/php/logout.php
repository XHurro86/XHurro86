<?php
    session_start();
    session_unset();//limpia las variables de sesion
    session_destroy();//destruye todas las variables de session
    header("Location:../login.php");
    exit();
?>