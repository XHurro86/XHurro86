<?php
require_once("../conexion/conexion.php");

$nombre = $_POST["nombrephp"];
$clave = $_POST["clavephp"];
$tipo= $_POST["tipophp"];
$estado = $_POST["estadophp"];

$sql = "insert into productos(pro_nombre, pro_clave, pro_tipo, pro_estado)values ('$nombre', '$clave', '$tipo', '$estado')";
 
if(mysqli_query($conn, $sql)) {
    echo "CLIENTE GUARDADO";

}else{
     echo "ERROR" . mysqli_error(mysql: $conn);
}
?>
