<?php
    require_once("../conexion/conexion.php");//invocamos al archivo que posee la llave de bd

    //se declara una variable para saber que realizar
    //si insertar o listar o modificar o eliminar cliente
    $action = "";
    //cuando se utiliza el insert, update y delete se utiliza el metodo POST
    //porque  esos comandos necesitan datos
    //cuando se utiliza el select se utiliza el metodo GET
    //porque no necesita datos pero si necesita peticion al servidor

    if(isset($_POST['accion'])){
        $action = $_POST['accion'];
    }elseif($_GET['accion']){
        $action = $_GET['accion'];
    }

    if($action == "insertar"){
    $nombre = $_POST['nombrephp'];
    $apellido = $_POST['apellidophp'];
    $ruc = $_POST['rucphp'];

    $sql = "insert into clientes(cli_nombre, cli_apellido, cli_ruc) values ('$nombre', '$apellido', '$ruc')";

    if(mysqli_query($conn, $sql)){
        echo "CLIENTE GUARDADO";
    }else{
        echo "Error: " . mysqli_error($conn);
    }
    mysqli_close($conn);
}elseif($action == "listar"){
    //hay que colocar el codigo  para el select
    $sql = "select * from clientes";//se crea el  query
    $result = mysqli_query($conn,$sql);
    //se ejecuta y los resultados del select se almacena en la variable resultSet
    $cliente = []; //se declara un array vacio para que se cargue con los valores del result
    //se crea un array porque no se pùede enviar $result de forma  directa

    //validar si result tiene filas y si funciono
    if($result && mysqli_num_rows($result) > 0){
        //se saca del result la primera linea (fetch assoc)
        while($row = mysqli_fetch_assoc($result)){
            $cliente[] = $row;
        }
    }
    //utilizar un JSON ejemplo: idclientes:1, cli_nombre: Abel, cli_apellido: Olmedo
    header('content-Type: application/json');
    echo json_encode(value:$cliente);

    mysqli_close($conn); 

}elseif($action == "editar"){
    //hay que colocar el codigo para el  update
    $codigo = $_POST['codigo'];
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $ruc = $_POST['ruc'];
    //se crea el sql
    $sql = "update clientes set cli_nombre='$nombre',cli_apellido='$apellido',cli_ruc='$ruc' where idclientes='$codigo'";

    if(mysqli_query($conn, $sql)){
        echo "CLIENTE MODIFICADO";
    }else{
        echo "Error: " . mysqli_error($conn);
    }
    mysqli_close($conn);

}elseif($action == "eliminar"){
    //hay que colocar codigo para el debate
    $codigo = $_POST['codigo'];

    $sql = "delete from clientes where idclientes = '$codigo'";

    if(mysqli_query($conn,$sql)){
        echo "CLIENTE ELIMINADO";
    }else{
        echo "Error: ". mysqli_error($conn);
    }
    mysqli_close($conn);
}
?>