<?php
require_once("../conexion/conexion.php");

$nombre = $_POST["nombrephp"];
$costo = $_POST["rucphp"];
$precio= $_POST["telefonoophp"];
$stock = $_POST["correophp"];

$sql = "insert into productos(pro_nombre, pro_ruc, pro_telefono, pro_correo)values ('$nombre', '$ruc', '$telefono', '$correo')";
 
if(mysqli_query($conn, $sql)) {
    echo "CLIENTE GUARDADO";

}else{
     echo "ERROR" . mysqli_error(mysql: $conn);
}
?>