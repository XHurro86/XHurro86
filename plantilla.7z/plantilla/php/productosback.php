<?php
    require_once("../conexion/conexion.php");//invocamos al archivo que posee la llave de bd

    $nombre = $_POST['nombrephp'];
    $costo = $_POST['costophp'];
    $precio = $_POST['preciophp'];
    $stock = $_POST['stockphp'];
    $iva = $_POST['ivaphp'];

    $sql = "insert into productos(pro_nombre, pro_costo, pro_precio, pro_stock, pro_iva) values ('$nombre', '$costo', '$precio', '$stock','$iva')";

    if(mysqli_query($conn, $sql)){
        echo "PRODUCTO GUARDADO";
    }else{
        echo "Error: " . mysqli_error($conn);

    }
?>