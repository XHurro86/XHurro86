<?php
    session_start();
    if(!isset($_SESSION['idusuarios'])){
        header("Location: login.php");
        exit();
    }
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>Plantilla</title>
</head>
<body>
    <header>
        <div>
            <img src="" alt="HOME">
        </div>
        <nav>
            <a href="paginas/clientes.php">CLIENTES</a>
            <a href="paginas/productos.php">PRODUCTOS</a>
            <a href="paginas/proveedores.php">PROVEEDORES</a>
            <a href="paginas/personales.php">Personales</a>
            <a href="paginas/usuarios.php">Usuarios</a>
        </nav>
        <a href="paginas/clientes.php">CLIENTES</a>
        <a href="php/logout.php">Cerrar sesion</a>
    </header>

    <main>
        <button onclick="abrir()">ABRIR MODAL</button>
    </main>

    <footer>
        <p>Mi pie de página</p>
    </footer>

    <!-- Modal -->
    <div id="modal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="cerrar()">&times;</span>
            <h5>Contenido de la modal</h5>
            <button type="button" onclick="cerrar()">ACEPTAR</button>
        </div>
    </div>

    <script src="js/script.js"></script>
</body>
</html>
